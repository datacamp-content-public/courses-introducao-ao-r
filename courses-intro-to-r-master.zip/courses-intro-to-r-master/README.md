## Introduction to R

This repository contains the source files for the introduction to R course (id 58).
